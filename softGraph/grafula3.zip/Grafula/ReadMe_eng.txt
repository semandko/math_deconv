Read HELP

		Grafula3
		
		v 2.10  from  24.10.2000



The purpose (duty)

Digitazing (Numbering)  of  any plots -  date input into Excel.
Initial material  - scanned pictures (plots)  in BMP- format (from books, papers, drawn by hand...) 
Total  material  - a text - pairs of figures ( coordinates "x - y" )  are copied   by  means of clipboard and  paste  into  Excel  forming  two date columns.
The time ,  that is need for  input of a plot  (ignoring scanning) depends on strength of  hand and mouse quality .  On sample  test.bmp  -  40 seconds  from  program starting  to inputing of points into Excel.

Delivery  set

grafula_3.exe		executable file 
grafula3.ini		file of setup  and parameters
ReadMe_eng.txt		short description in English (this text)
ReadMe_rus.rus		descrpition in Russian
/Sample  		the examples  of initial date   - 
                           a drawn plot, an magazine  example , a plot with logarithmic scale 

Principle of operation
A graghical file chosen by you  is depicted on  screen. Any size file  is scaled to window size. You indicate  where coordinate axises are in it (the point 0,0; the  points of minimum and maximum  axially readings ). Input  the numbers corresponding to these points.
Then you can input (and remove) up to 1000 points describing (pointing) position of a plot curve. The points can be input (removed) in any order - point massif  is overpacked and sorted automatically.
As point inputing (and at any changes of axis parametres)  two figure  columns of input poins (X and Y) are formed in special text window. The date are copied by means of clipboard. Then  you paste  the date into chosen cell.  Leading with this cell two date columns   are formed to the right and to the left. Then you may do everything that Excel allows.


Set up
It does not require  special instalation. Unpack  archive  and start grafula.exe.

Short instruction
At program starting you see three program window:
1. Main window  - with comand button field   and a big field for a plot.
2. Setup window - for mode setup and  figures input.
3. Table window - for reading the date obtained at numbering of a plot.

The main window
<< Opening file with picture>> - opening of a dialog window  of select a picture  for  loading. It is practically a stansard dialog window Windows for opening of files.
There is the  window of preliminary reading  of marked file.  The file is chosen from a file list  by one click  of the left mouse  button. Then  the file appears   in  preliminary reading window. If  chosen file that you wanted  you  load the chosen file and come back to basic program window
<<To copy a picture from  clipboard>>  copies to  clipboard  the date represented in table window.
<<On basic window>>  - select a basic window
<<On table window>>  - select a  window with table 
<<On setup window>>  - select   setup window
<<The plot points input  >>  -  input (indicating on a picture) of points being a plot curve.
<<Input of point 0,0>> - input of  point being coordinates of the origin of a plot
<<Input of point MaxX>> - input of point  having maximum value X
<<Input of point MaxY>> - input of point having maximum value Y
<<Delete the date>>  -  deleting of  only  the date (coordinates) of all the chosen points
<< Help>> - Informaion window - version, names, Internet address are depicted.
<<Exit>>   - exit

Table window
The obtained date of  coordinate values   indicated by you and  the plot points  in accordance with given setup are  represented  here.

Window of setup and modes
A part of setup is turned off or  is not used (for the present)
[Setup of colours of marks]  - is turned off
[Select  a plot curve for input]  - is not used
[Input of quantity of curves]  - is not used
[Select  mark type]  - sets  diameter  of circle - mark  at  indicating of the points on a plot
[Input of axis values] - four fields for input of numbers setting the values  axially .
[Input of table format]  - sets a kind of figure in table - is not used
[Select  sorting mode] - to sort or not  the table date (by column X)
[Select  type of  decimal point]  - sets  which decimal divisor should be used at forming of text with the table data (depending on Excel setup   different symbols are used)
[Scale type on Y] -  usual  or logarithmic scale  of Y-axis 
[Select Interface Language]  - setup of interface language

Sequence
The program was started. The picture was chosen.  Then sequence is not of principle.
You have to set coordinate axis positions  and  enter  numerical  values  corresponding  to their extreme points . Put (click)  on a plot curve  desiravle quantity of point (maximum 1000). Entered points can be out  the extreme  points of coordinate axises. 
The point is deleted by means of repeated click in the same place  at  pressed key  Ctrl.
The result data  in table window are changed  at changing of the limits and coordinate axis positions.
Then calculated data are copied into clipboard and pasted into Excel.

Processing of logarithmic plots
(Y-scale - logarithmic)
Point 0,0 should be indicated where by X - 0 and by Y - 100
Point MaxY should be indicated where by X - 0 and by Y - 101
Numerical values of points MinY and MaxY  should not be entered.

Appearance  problems
In given version the sizes and controling elements have been  corrected. The test on computer with videocard Matrox Mystique and monitor LG 56m in modes 640x480  800x600 and 1024x768 at screen font - normal (100%) and large (125%).
Please inform me about noticed  errors  indicating modes of operation (screen setup).

Conditions of  distributing  
The program is distributed as FreeWare. If you are able  and want  to  support  author, it is greeted.
If you have the plots the processing which  is dufficult for you, write me.
If you have questions, offers, advices, requests and wishes ,  write me too: wesik@comset.net

See homepage: http://home.comset.net/wesik/grafula3   to find possible updating.
